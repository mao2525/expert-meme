/*
  # Create bills and bill items tables

  1. New Tables
    - `bills`
      - `id` (uuid, primary key)
      - `bill_no` (text, unique 4-digit sequence)
      - `customer_name` (text)
      - `customer_phone` (text)
      - `customer_address` (text)
      - `bill_date` (date)
      - `false_ceiling_cost` (numeric)
      - `total_wood_work` (numeric)
      - `total_cost` (numeric)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    - `bill_items`
      - `id` (uuid, primary key)
      - `bill_id` (uuid, foreign key)
      - `unit` (text)
      - `height` (numeric)
      - `width` (numeric)
      - `sqft` (numeric)
      - `finish` (text)
      - `rate_per_sqft` (numeric)
      - `amount` (numeric)
      - `sort_order` (integer)

  2. Security
    - Enable RLS on both tables
    - Add policies for public access (since this is an internal business tool)
*/

-- Create bills table
CREATE TABLE IF NOT EXISTS bills (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  bill_no text UNIQUE NOT NULL,
  customer_name text NOT NULL DEFAULT '',
  customer_phone text NOT NULL DEFAULT '',
  customer_address text NOT NULL DEFAULT '',
  bill_date date NOT NULL DEFAULT CURRENT_DATE,
  false_ceiling_cost numeric DEFAULT 0,
  total_wood_work numeric DEFAULT 0,
  total_cost numeric DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create bill_items table
CREATE TABLE IF NOT EXISTS bill_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  bill_id uuid REFERENCES bills(id) ON DELETE CASCADE,
  unit text NOT NULL DEFAULT '',
  height numeric,
  width numeric,
  sqft numeric,
  finish text NOT NULL DEFAULT '',
  rate_per_sqft numeric,
  amount numeric NOT NULL DEFAULT 0,
  sort_order integer NOT NULL DEFAULT 0
);

-- Enable RLS
ALTER TABLE bills ENABLE ROW LEVEL SECURITY;
ALTER TABLE bill_items ENABLE ROW LEVEL SECURITY;

-- Create policies for public access (internal business tool)
CREATE POLICY "Allow all operations on bills"
  ON bills
  FOR ALL
  TO public
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow all operations on bill_items"
  ON bill_items
  FOR ALL
  TO public
  USING (true)
  WITH CHECK (true);

-- Create function to generate bill number
CREATE OR REPLACE FUNCTION generate_bill_number()
RETURNS text AS $$
DECLARE
  new_number text;
  counter integer := 1;
BEGIN
  LOOP
    -- Generate 4-digit number with leading zeros
    new_number := LPAD(counter::text, 4, '0');
    
    -- Check if this number already exists
    IF NOT EXISTS (SELECT 1 FROM bills WHERE bill_no = new_number) THEN
      RETURN new_number;
    END IF;
    
    counter := counter + 1;
    
    -- Safety check to prevent infinite loop
    IF counter > 9999 THEN
      RAISE EXCEPTION 'All bill numbers exhausted';
    END IF;
  END LOOP;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to auto-generate bill number
CREATE OR REPLACE FUNCTION set_bill_number()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.bill_no IS NULL OR NEW.bill_no = '' THEN
    NEW.bill_no := generate_bill_number();
  END IF;
  NEW.updated_at := now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_set_bill_number
  BEFORE INSERT OR UPDATE ON bills
  FOR EACH ROW
  EXECUTE FUNCTION set_bill_number();