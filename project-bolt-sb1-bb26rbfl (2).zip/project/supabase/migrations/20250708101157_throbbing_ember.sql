/*
  # Setup banner image storage

  1. Storage
    - Create a public bucket for banner images
    - Set up proper policies for public access
  
  2. Security
    - Allow public read access to banner images
    - Restrict upload to authenticated users (if needed)
*/

-- Create storage bucket for banner images
INSERT INTO storage.buckets (id, name, public) 
VALUES ('banners', 'banners', true)
ON CONFLICT (id) DO NOTHING;

-- Allow public access to view banner images
CREATE POLICY "Public Access to Banner Images" ON storage.objects
FOR SELECT USING (bucket_id = 'banners');

-- Allow public upload of banner images (you can restrict this later)
CREATE POLICY "Allow Banner Upload" ON storage.objects
FOR INSERT WITH CHECK (bucket_id = 'banners');