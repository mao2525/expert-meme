import React, { useState, useEffect, useRef } from 'react';
import { FileText, Calculator, Home, Edit3, Save, X, GripVertical, Calendar, Database, Plus } from 'lucide-react';
import { SavedBillsModal } from './components/SavedBillsModal';
import { supabase, type BillWithItems, type BillItem } from './lib/supabase';

interface EstimationItem {
  id: string;
  unit: string;
  height?: number;
  width?: number;
  sqft?: number;
  finish: string;
  ratePerSqft?: number;
  amount: number;
}

interface CustomerDetails {
  name: string;
  date: string;
  address: string;
  phone: string;
}

function App() {
  const [currentBillId, setCurrentBillId] = useState<string | null>(null);
  const [currentBillNo, setCurrentBillNo] = useState<string>('');
  const [showSavedBills, setShowSavedBills] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [saveMessage, setSaveMessage] = useState<string | null>(null);

  const [customerDetails, setCustomerDetails] = useState<CustomerDetails>({
    name: '',
    date: new Date().toISOString().split('T')[0],
    address: '',
    phone: ''
  });

  const [isEditingCustomer, setIsEditingCustomer] = useState(false);
  const [tempCustomerDetails, setTempCustomerDetails] = useState(customerDetails);

  const [estimationItems, setEstimationItems] = useState<EstimationItem[]>([]);

  const [falseCeilingCost, setFalseCeilingCost] = useState(0);
  const [draggedItem, setDraggedItem] = useState<string | null>(null);
  const [dragOverIndex, setDragOverIndex] = useState<number | null>(null);

  // Generate a new bill number when component mounts
  useEffect(() => {
    generateNewBillNumber();
  }, []);

  const generateNewBillNumber = async () => {
    try {
      const { data, error } = await supabase.rpc('generate_bill_number');
      if (error) throw error;
      setCurrentBillNo(data || '0001');
    } catch (err) {
      console.error('Error generating bill number:', err);
      // Fallback to random 4-digit number
      setCurrentBillNo(Math.floor(1000 + Math.random() * 9000).toString());
    }
  };

  // Calculate sqft when height and width change
  const calculateSqft = (height?: number, width?: number): number => {
    if (height && width) {
      return parseFloat((height * width).toFixed(2));
    }
    return 0;
  };

  // Calculate amount when sqft and rate change
  const calculateAmount = (sqft?: number, rate?: number): number => {
    if (sqft && rate) {
      return sqft * rate;
    }
    return 0;
  };

  // Update item with automatic calculations
  const updateItem = (id: string, field: keyof EstimationItem, value: any) => {
    setEstimationItems(prev => prev.map(item => {
      if (item.id === id) {
        const updatedItem = { ...item, [field]: value };
        
        // Auto-calculate sqft if height or width changes
        if (field === 'height' || field === 'width') {
          const newSqft = calculateSqft(
            field === 'height' ? value : updatedItem.height,
            field === 'width' ? value : updatedItem.width
          );
          updatedItem.sqft = newSqft > 0 ? newSqft : updatedItem.sqft;
        }
        
        // Auto-calculate amount if sqft or rate changes
        if (field === 'sqft' || field === 'ratePerSqft' || field === 'height' || field === 'width') {
          const newAmount = calculateAmount(updatedItem.sqft, updatedItem.ratePerSqft);
          if (newAmount > 0) {
            updatedItem.amount = newAmount;
          }
        }
        
        return updatedItem;
      }
      return item;
    }));
  };

  // Drag and drop handlers
  const handleDragStart = (e: React.DragEvent, itemId: string) => {
    setDraggedItem(itemId);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e: React.DragEvent, index: number) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    setDragOverIndex(index);
  };

  const handleDragLeave = () => {
    setDragOverIndex(null);
  };

  const handleDrop = (e: React.DragEvent, dropIndex: number) => {
    e.preventDefault();
    
    if (!draggedItem) return;
    
    const dragIndex = estimationItems.findIndex(item => item.id === draggedItem);
    if (dragIndex === dropIndex) return;
    
    const newItems = [...estimationItems];
    const draggedItemData = newItems[dragIndex];
    
    // Remove dragged item
    newItems.splice(dragIndex, 1);
    
    // Insert at new position
    const insertIndex = dragIndex < dropIndex ? dropIndex - 1 : dropIndex;
    newItems.splice(insertIndex, 0, draggedItemData);
    
    setEstimationItems(newItems);
    setDraggedItem(null);
    setDragOverIndex(null);
  };

  const handleDragEnd = () => {
    setDraggedItem(null);
    setDragOverIndex(null);
  };

  // Add new row
  const addNewRow = () => {
    const newId = (estimationItems.length + 1).toString();
    const newItem: EstimationItem = {
      id: newId,
      unit: 'New Item',
      finish: 'Laminate',
      amount: 0
    };
    setEstimationItems([...estimationItems, newItem]);
  };

  // Save bill to database
  const saveBill = async () => {
    setIsSaving(true);
    setSaveMessage(null);

    try {
      const totalWoodWorkCalc = estimationItems.reduce((sum, item) => sum + item.amount, 0);
      const totalCostCalc = totalWoodWorkCalc + falseCeilingCost;

      let billId = currentBillId;

      if (currentBillId) {
        // Update existing bill
        const { error: billError } = await supabase
          .from('bills')
          .update({
            customer_name: customerDetails.name,
            customer_phone: customerDetails.phone,
            customer_address: customerDetails.address,
            bill_date: customerDetails.date,
            false_ceiling_cost: falseCeilingCost,
            total_wood_work: totalWoodWorkCalc,
            total_cost: totalCostCalc,
            updated_at: new Date().toISOString()
          })
          .eq('id', currentBillId);

        if (billError) throw billError;

        // Delete existing items
        const { error: deleteError } = await supabase
          .from('bill_items')
          .delete()
          .eq('bill_id', currentBillId);

        if (deleteError) throw deleteError;
      } else {
        // Create new bill
        const { data: billData, error: billError } = await supabase
          .from('bills')
          .insert({
            bill_no: currentBillNo,
            customer_name: customerDetails.name,
            customer_phone: customerDetails.phone,
            customer_address: customerDetails.address,
            bill_date: customerDetails.date,
            false_ceiling_cost: falseCeilingCost,
            total_wood_work: totalWoodWorkCalc,
            total_cost: totalCostCalc
          })
          .select()
          .single();

        if (billError) throw billError;
        billId = billData.id;
        setCurrentBillId(billId);
      }

      // Insert bill items
      const billItems = estimationItems.map((item, index) => ({
        bill_id: billId,
        unit: item.unit,
        height: item.height || null,
        width: item.width || null,
        sqft: item.sqft || null,
        finish: item.finish,
        rate_per_sqft: item.ratePerSqft || null,
        amount: item.amount,
        sort_order: index
      }));

      const { error: itemsError } = await supabase
        .from('bill_items')
        .insert(billItems);

      if (itemsError) throw itemsError;

      setSaveMessage('Bill saved successfully!');
      setTimeout(() => setSaveMessage(null), 3000);
    } catch (err) {
      console.error('Error saving bill:', err);
      setSaveMessage('Failed to save bill. Please try again.');
      setTimeout(() => setSaveMessage(null), 3000);
    } finally {
      setIsSaving(false);
    }
  };

  // Load bill from saved bills
  const loadBill = (bill: BillWithItems) => {
    setCurrentBillId(bill.id);
    setCurrentBillNo(bill.bill_no);
    
    setCustomerDetails({
      name: bill.customer_name,
      phone: bill.customer_phone,
      address: bill.customer_address,
      date: bill.bill_date
    });

    setFalseCeilingCost(bill.false_ceiling_cost);

    const loadedItems = bill.bill_items.map((item: BillItem) => ({
      id: item.id,
      unit: item.unit,
      height: item.height || undefined,
      width: item.width || undefined,
      sqft: item.sqft || undefined,
      finish: item.finish,
      ratePerSqft: item.rate_per_sqft || undefined,
      amount: item.amount
    }));

    setEstimationItems(loadedItems);
  };

  // Create new bill
  const createNewBill = () => {
    setCurrentBillId(null);
    generateNewBillNumber();
    
    setCustomerDetails({
      name: '',
      date: new Date().toISOString().split('T')[0],
      address: '',
      phone: ''
    });

    setEstimationItems([]);

    setFalseCeilingCost(0);
  };

  // Remove row
  const removeRow = (id: string) => {
    setEstimationItems(prev => prev.filter(item => item.id !== id));
  };

  const totalWoodWork = estimationItems.reduce((sum, item) => sum + item.amount, 0);
  const totalCost = totalWoodWork + falseCeilingCost;

  const handleCustomerSave = () => {
    setCustomerDetails(tempCustomerDetails);
    setIsEditingCustomer(false);
  };

  const handleCustomerCancel = () => {
    setTempCustomerDetails(customerDetails);
    setIsEditingCustomer(false);
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-IN', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    }).replace(/\//g, '.');
  };

  const handlePrint = () => {
    try {
      // Hide all non-printable elements temporarily
      const printHideElements = document.querySelectorAll('.print-hide');
      const originalDisplays: string[] = [];
      
      printHideElements.forEach((element, index) => {
        const htmlElement = element as HTMLElement;
        originalDisplays[index] = htmlElement.style.display;
        htmlElement.style.display = 'none';
      });
      
      // Add print class to body for print-specific styling
      document.body.classList.add('printing');
      
      // Trigger print
      window.print();
      
      // Restore elements after print dialog closes
      setTimeout(() => {
        printHideElements.forEach((element, index) => {
          const htmlElement = element as HTMLElement;
          htmlElement.style.display = originalDisplays[index];
        });
        document.body.classList.remove('printing');
      }, 100);
      
    } catch (error) {
      console.error('Print error:', error);
      window.print();
    }
  };

  const EditableCell = ({ value, onChange, type = 'text', className = '' }: {
    value: any;
    onChange: (value: any) => void;
    type?: string;
    className?: string;
  }) => {
    const [isEditing, setIsEditing] = useState(false);
    const [tempValue, setTempValue] = useState(value);

    useEffect(() => {
      setTempValue(value);
    }, [value]);

    const handleSave = () => {
      const parsedValue = type === 'number' ? parseFloat(tempValue) || 0 : tempValue;
      onChange(parsedValue);
      setIsEditing(false);
    };

    const handleCancel = () => {
      setTempValue(value);
      setIsEditing(false);
    };

    const handleKeyDown = (e: React.KeyboardEvent) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        handleSave();
      }
      if (e.key === 'Escape') {
        e.preventDefault();
        handleCancel();
      }
    };

    if (isEditing) {
      return (
        <div className="flex items-center space-x-1">
          <input
            type={type}
            value={tempValue}
            onChange={(e) => setTempValue(e.target.value)}
            className="w-full px-2 py-1 text-sm border border-shodshi-green rounded focus:outline-none focus:ring-2 focus:ring-shodshi-green"
            onKeyDown={handleKeyDown}
            onBlur={handleSave}
            autoFocus
          />
          <button onClick={handleSave} className="text-shodshi-green hover:text-shodshi-green-dark print-hide">
            <Save className="w-3 h-3" />
          </button>
          <button onClick={handleCancel} className="text-red-600 hover:text-red-800 print-hide">
            <X className="w-3 h-3" />
          </button>
        </div>
      );
    }

    return (
      <div 
        className={`cursor-pointer hover:bg-shodshi-light px-2 py-1 rounded group print-no-hover ${className}`}
        onClick={() => setIsEditing(true)}
      >
        <span>{type === 'number' && value ? value.toLocaleString() : value || '-'}</span>
        <Edit3 className="w-3 h-3 ml-1 opacity-0 group-hover:opacity-50 inline print-hide" />
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-cream-light p-2 print-page">
      <div className="max-w-5xl mx-auto bg-white shadow-lg rounded-lg overflow-hidden print-full-width">
        {/* Header Section */}
        <div className="bg-shodshi-gradient text-white p-4 print-header">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 rounded-full flex items-center justify-center border-3 border-white shadow-lg overflow-hidden bg-white">
                <img 
                  src="/IMG-20250613-WA0025~2.jpg" 
                  alt="Shodshi Luxury Interiors Logo" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div>
                <h1 className="text-xl font-bold tracking-wide">SHODSHI LUXURY INTERIORS DECORATORS</h1>
                <p className="text-cream-light text-sm mt-1">All kinds of Furnitures & Interior Decorators</p>
                <p className="text-xs text-cream-light mt-1">Prop: S. Nagaraju Achari | Cell: 9505564415, 8074244515</p>
              </div>
            </div>
            
            {/* Bill Number - Right Corner */}
            <div className="bill-number-container">
              <div className="text-right">
                <p className="bill-number-text">Bill No: #{currentBillNo}</p>
              </div>
            </div>
            
            <div className="print-hide">
              <div className="flex space-x-2">
                <button
                  onClick={() => setShowSavedBills(true)}
                  className="bg-white text-shodshi-purple px-4 py-2 rounded-lg font-medium hover:bg-gray-100 transition-colors flex items-center space-x-2 shadow-lg"
                >
                  <Database className="w-4 h-4" />
                  <span>Saved Bills</span>
                </button>
                <button
                  onClick={handlePrint}
                  className="bg-white text-shodshi-purple px-4 py-2 rounded-lg font-medium hover:bg-gray-100 transition-colors flex items-center space-x-2 shadow-lg"
                >
                  <FileText className="w-4 h-4" />
                  <span>Print PDF</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Sub-header with Editable Customer Details */}
        <div className="bg-cream-bg p-4 border-b-2 border-shodshi-green print-subheader">
          <div className="flex items-center justify-between">
            <div className="flex-1">
              {isEditingCustomer ? (
                <div className="space-y-3 print-hide">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="flex items-center space-x-3">
                      <label className="font-medium text-shodshi-purple text-sm w-20">Name:</label>
                      <input
                        type="text"
                        value={tempCustomerDetails.name}
                        onChange={(e) => setTempCustomerDetails({...tempCustomerDetails, name: e.target.value})}
                        className="flex-1 px-2 py-1 border border-shodshi-green rounded-lg focus:outline-none focus:ring-2 focus:ring-shodshi-green text-sm"
                      />
                    </div>
                    <div className="flex items-center space-x-3">
                      <label className="font-medium text-shodshi-purple text-sm w-20">Phone:</label>
                      <input
                        type="tel"
                        value={tempCustomerDetails.phone}
                        onChange={(e) => setTempCustomerDetails({...tempCustomerDetails, phone: e.target.value})}
                        className="flex-1 px-2 py-1 border border-shodshi-green rounded-lg focus:outline-none focus:ring-2 focus:ring-shodshi-green text-sm"
                      />
                    </div>
                    <div className="flex items-center space-x-3">
                      <label className="font-medium text-shodshi-purple text-sm w-20">Date:</label>
                      <input
                        type="date"
                        value={tempCustomerDetails.date}
                        onChange={(e) => setTempCustomerDetails({...tempCustomerDetails, date: e.target.value})}
                        className="flex-1 px-2 py-1 border border-shodshi-green rounded-lg focus:outline-none focus:ring-2 focus:ring-shodshi-green text-sm"
                      />
                    </div>
                    <div className="flex items-center space-x-3">
                      <label className="font-medium text-shodshi-purple text-sm w-20">Address:</label>
                      <input
                        type="text"
                        value={tempCustomerDetails.address}
                        onChange={(e) => setTempCustomerDetails({...tempCustomerDetails, address: e.target.value})}
                        className="flex-1 px-2 py-1 border border-shodshi-green rounded-lg focus:outline-none focus:ring-2 focus:ring-shodshi-green text-sm"
                      />
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <button
                      onClick={handleCustomerSave}
                      className="bg-shodshi-green text-white px-3 py-1 rounded-lg hover:bg-shodshi-green-dark flex items-center space-x-1 text-sm"
                    >
                      <Save className="w-3 h-3" />
                      <span>Save</span>
                    </button>
                    <button
                      onClick={handleCustomerCancel}
                      className="bg-gray-600 text-white px-3 py-1 rounded-lg hover:bg-gray-700 flex items-center space-x-1 text-sm"
                    >
                      <X className="w-3 h-3" />
                      <span>Cancel</span>
                    </button>
                  </div>
                </div>
              ) : (
                <div>
                  <h2 className="text-xl font-bold text-shodshi-purple mb-1">
                    Estimation Proposal for {customerDetails.name}
                  </h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
                    <p className="text-shodshi-purple font-medium">
                      <Calendar className="w-4 h-4 inline mr-1" />
                      Dated: {formatDate(customerDetails.date)}
                    </p>
                    <p className="text-shodshi-purple font-medium">
                      <Home className="w-4 h-4 inline mr-1" />
                      Phone: {customerDetails.phone}
                    </p>
                  </div>
                  <p className="text-shodshi-purple font-medium text-sm mt-1">
                    Address: {customerDetails.address}
                  </p>
                  <p className="text-gray-700 mt-2 italic text-sm">
                    "Dear {customerDetails.name}, Thank you for choosing Shodshi Interiors. Please find your detailed interior estimate below:"
                  </p>
                </div>
              )}
            </div>
            {!isEditingCustomer && (
              <button
                onClick={() => setIsEditingCustomer(true)}
                className="bg-shodshi-green text-white px-3 py-2 rounded-lg hover:bg-shodshi-green-dark flex items-center space-x-2 print-hide text-sm"
              >
                <Edit3 className="w-3 h-3" />
                <span>Edit Details</span>
              </button>
            )}
          </div>
        </div>

        {/* Estimation Table */}
        <div className="p-3 print-table-section">
          <div className="overflow-x-auto">
            <table className="w-full border-collapse border-2 border-gray-400 print-table text-xs">
              <thead>
                <tr className="bg-shodshi-gradient text-white">
                  <th className="border-2 border-gray-400 px-2 py-2 text-center font-bold print-hide">Drag</th>
                  <th className="border-2 border-gray-400 px-2 py-2 text-left font-bold">Unit</th>
                  <th className="border-2 border-gray-400 px-2 py-2 text-center font-bold">Height</th>
                  <th className="border-2 border-gray-400 px-2 py-2 text-center font-bold">Width</th>
                  <th className="border-2 border-gray-400 px-2 py-2 text-center font-bold">Sqft</th>
                  <th className="border-2 border-gray-400 px-2 py-2 text-center font-bold">Finish</th>
                  <th className="border-2 border-gray-400 px-2 py-2 text-center font-bold">Rate/Sqft</th>
                  <th className="border-2 border-gray-400 px-2 py-2 text-center font-bold">Amount (₹)</th>
                  <th className="border-2 border-gray-400 px-2 py-2 text-center font-bold print-hide">Actions</th>
                </tr>
              </thead>
              <tbody>
                {estimationItems.map((item, index) => (
                  <tr 
                    key={item.id} 
                    className={`${index % 2 === 0 ? 'bg-gray-50' : 'bg-white'} ${
                      dragOverIndex === index ? 'border-t-4 border-shodshi-green' : ''
                    }`}
                    draggable
                    onDragStart={(e) => handleDragStart(e, item.id)}
                    onDragOver={(e) => handleDragOver(e, index)}
                    onDragLeave={handleDragLeave}
                    onDrop={(e) => handleDrop(e, index)}
                    onDragEnd={handleDragEnd}
                  >
                    <td className="border-2 border-gray-300 px-1 py-1 text-center print-hide">
                      <GripVertical className="w-4 h-4 text-gray-400 cursor-grab active:cursor-grabbing mx-auto" />
                    </td>
                    <td className="border-2 border-gray-300 px-1 py-1">
                      <EditableCell
                        value={item.unit}
                        onChange={(value) => updateItem(item.id, 'unit', value)}
                        className="font-medium text-gray-900"
                      />
                    </td>
                    <td className="border-2 border-gray-300 px-1 py-1 text-center">
                      <EditableCell
                        value={item.height}
                        onChange={(value) => updateItem(item.id, 'height', value)}
                        type="number"
                        className="text-gray-700"
                      />
                    </td>
                    <td className="border-2 border-gray-300 px-1 py-1 text-center">
                      <EditableCell
                        value={item.width}
                        onChange={(value) => updateItem(item.id, 'width', value)}
                        type="number"
                        className="text-gray-700"
                      />
                    </td>
                    <td className="border-2 border-gray-300 px-1 py-1 text-center">
                      <EditableCell
                        value={item.sqft}
                        onChange={(value) => updateItem(item.id, 'sqft', value)}
                        type="number"
                        className="text-gray-700"
                      />
                    </td>
                    <td className="border-2 border-gray-300 px-1 py-1 text-center">
                      <EditableCell
                        value={item.finish}
                        onChange={(value) => updateItem(item.id, 'finish', value)}
                        className="text-gray-700"
                      />
                    </td>
                    <td className="border-2 border-gray-300 px-1 py-1 text-center">
                      <EditableCell
                        value={item.ratePerSqft}
                        onChange={(value) => updateItem(item.id, 'ratePerSqft', value)}
                        type="number"
                        className="text-gray-700"
                      />
                    </td>
                    <td className="border-2 border-gray-300 px-1 py-1 text-center">
                      <EditableCell
                        value={item.amount}
                        onChange={(value) => updateItem(item.id, 'amount', value)}
                        type="number"
                        className="font-bold text-shodshi-green"
                      />
                    </td>
                    <td className="border-2 border-gray-300 px-1 py-1 text-center print-hide">
                      <button
                        onClick={() => removeRow(item.id)}
                        className="text-red-600 hover:text-red-800 p-1"
                        title="Remove row"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          
          <div className="mt-2 print-hide flex items-center justify-between">
            <div className="flex space-x-2">
              <button
                onClick={addNewRow}
                className="bg-shodshi-green text-white px-3 py-2 rounded-lg hover:bg-shodshi-green-dark transition-colors text-sm flex items-center space-x-1"
              >
                <Plus className="w-4 h-4" />
                <span>Add New Item</span>
              </button>
              <button
                onClick={saveBill}
                disabled={isSaving}
                className="bg-shodshi-purple text-white px-3 py-2 rounded-lg hover:bg-shodshi-purple-dark transition-colors text-sm flex items-center space-x-1 disabled:opacity-50"
              >
                <Save className="w-4 h-4" />
                <span>{isSaving ? 'Saving...' : 'Save Bill'}</span>
              </button>
              <button
                onClick={createNewBill}
                className="bg-gray-600 text-white px-3 py-2 rounded-lg hover:bg-gray-700 transition-colors text-sm flex items-center space-x-1"
              >
                <FileText className="w-4 h-4" />
                <span>New Bill</span>
              </button>
            </div>
            
            {saveMessage && (
              <div className={`text-sm px-3 py-1 rounded ${
                saveMessage.includes('success') 
                  ? 'bg-green-100 text-green-700' 
                  : 'bg-red-100 text-red-700'
              }`}>
                {saveMessage}
              </div>
            )}
          </div>
        </div>

        {/* Summary Section */}
        <div className="bg-cream-bg p-3 border-t-2 border-shodshi-green print-summary">
          <div className="flex justify-end">
            <div className="w-full max-w-sm">
              <div className="bg-white rounded-lg shadow-lg p-3 border-2 border-shodshi-green print-summary-box">
                <h3 className="text-lg font-bold text-shodshi-purple mb-2 flex items-center">
                  <Calculator className="w-4 h-4 mr-2" />
                  Cost Summary
                </h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between items-center border-b border-gray-200 pb-1">
                    <span className="font-medium text-gray-700">Total Wood Work:</span>
                    <span className="font-bold text-shodshi-green">₹{totalWoodWork.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-center border-b border-gray-200 pb-1">
                    <span className="font-medium text-gray-700">False Ceiling & Electrical:</span>
                    <div className="flex items-center space-x-1">
                      <EditableCell
                        value={falseCeilingCost}
                        onChange={setFalseCeilingCost}
                        type="number"
                        className="font-bold text-shodshi-green"
                      />
                    </div>
                  </div>
                  <div className="flex justify-between items-center pt-1 border-t-2 border-shodshi-green">
                    <span className="text-lg font-bold text-shodshi-purple">Total Cost:</span>
                    <span className="text-xl font-bold text-shodshi-purple">₹{totalCost.toLocaleString()}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Extra Notes */}
        <div className="bg-cream-bg p-3 border-t border-shodshi-green print-notes">
          <div className="bg-shodshi-green-light rounded-lg p-3 mb-2 border-2 border-shodshi-green">
            <h4 className="font-bold text-shodshi-purple mb-1 text-sm">🎁 Free Accessories Included:</h4>
            <p className="text-shodshi-green-dark font-medium text-xs">
              Accessories worth ₹12,000: Shoe Stand + Tandem Basket (Only Fitting Free).
            </p>
          </div>

          <div className="bg-orange-50 rounded-lg p-3 mb-2 border-2 border-orange-300">
            <h4 className="font-bold text-orange-800 mb-1 text-sm">⚠️ Exclusions:</h4>
            <p className="text-orange-700 font-medium text-xs">
              Note: Excludes tile work and plumbing.
            </p>
          </div>

          <div className="text-center bg-cream-light rounded-lg p-3 border-2 border-shodshi-purple">
            <p className="text-shodshi-purple font-bold italic text-sm">
              "We look forward to turning your dream space into reality. Thank you!"
            </p>
          </div>
        </div>

        {/* Business Card Banner */}
        <div className="bg-white p-2 border-t-2 border-shodshi-green print-banner">
          <div className="flex justify-center">
            <img 
              src="/business-card-banner.jpg" 
              alt="Shodshi Luxury Interiors Business Card" 
              className="max-w-full h-auto rounded-lg shadow-lg border-2 border-shodshi-green"
              style={{ maxHeight: '120px' }}
            />
          </div>
        </div>

        {/* Footer */}
        <div className="bg-shodshi-gradient text-white p-2 text-center print-footer">
          <p className="text-xs font-medium">&copy; 2025 Shodshi Luxury Interiors Decorators. All rights reserved.</p>
          <p className="text-xs text-cream-light">KURNOOL & HYDERABAD</p>
        </div>
      </div>

      <SavedBillsModal
        isOpen={showSavedBills}
        onClose={() => setShowSavedBills(false)}
        onLoadBill={loadBill}
      />
    </div>
  );
}

export default App;