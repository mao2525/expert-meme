import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface Bill {
  id: string;
  bill_no: string;
  customer_name: string;
  customer_phone: string;
  customer_address: string;
  bill_date: string;
  false_ceiling_cost: number;
  total_wood_work: number;
  total_cost: number;
  created_at: string;
  updated_at: string;
}

export interface BillItem {
  id: string;
  bill_id: string;
  unit: string;
  height?: number;
  width?: number;
  sqft?: number;
  finish: string;
  rate_per_sqft?: number;
  amount: number;
  sort_order: number;
}

export interface BillWithItems extends Bill {
  bill_items: BillItem[];
}