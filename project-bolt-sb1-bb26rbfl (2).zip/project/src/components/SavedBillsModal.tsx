import React, { useState, useEffect } from 'react';
import { X, FileText, Calendar, User, Phone, MapPin, Trash2, Eye } from 'lucide-react';
import { supabase, type BillWithItems } from '../lib/supabase';

interface SavedBillsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoadBill: (bill: BillWithItems) => void;
}

export function SavedBillsModal({ isOpen, onClose, onLoadBill }: SavedBillsModalProps) {
  const [bills, setBills] = useState<BillWithItems[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      fetchBills();
    }
  }, [isOpen]);

  const fetchBills = async () => {
    setLoading(true);
    setError(null);
    
    try {
      const { data: billsData, error: billsError } = await supabase
        .from('bills')
        .select(`
          *,
          bill_items (*)
        `)
        .order('created_at', { ascending: false });

      if (billsError) throw billsError;

      // Sort bill items by sort_order
      const billsWithSortedItems = billsData?.map(bill => ({
        ...bill,
        bill_items: bill.bill_items.sort((a: any, b: any) => a.sort_order - b.sort_order)
      })) || [];

      setBills(billsWithSortedItems);
    } catch (err) {
      console.error('Error fetching bills:', err);
      setError('Failed to load saved bills');
    } finally {
      setLoading(false);
    }
  };

  const deleteBill = async (billId: string) => {
    if (!confirm('Are you sure you want to delete this bill?')) return;

    try {
      const { error } = await supabase
        .from('bills')
        .delete()
        .eq('id', billId);

      if (error) throw error;

      setBills(prev => prev.filter(bill => bill.id !== billId));
    } catch (err) {
      console.error('Error deleting bill:', err);
      setError('Failed to delete bill');
    }
  };

  const handleLoadBill = (bill: BillWithItems) => {
    onLoadBill(bill);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
        <div className="bg-shodshi-gradient text-white p-4 flex items-center justify-between">
          <h2 className="text-xl font-bold flex items-center">
            <FileText className="w-5 h-5 mr-2" />
            Saved Bills
          </h2>
          <button
            onClick={onClose}
            className="text-white hover:text-gray-200 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-4 overflow-y-auto max-h-[calc(90vh-80px)]">
          {error && (
            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
              {error}
            </div>
          )}

          {loading ? (
            <div className="flex items-center justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-shodshi-green"></div>
              <span className="ml-2 text-gray-600">Loading bills...</span>
            </div>
          ) : bills.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <FileText className="w-12 h-12 mx-auto mb-4 text-gray-300" />
              <p>No saved bills found</p>
            </div>
          ) : (
            <div className="grid gap-4">
              {bills.map((bill) => (
                <div
                  key={bill.id}
                  className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center space-x-4 mb-2">
                        <h3 className="text-lg font-bold text-shodshi-purple">
                          Bill #{bill.bill_no}
                        </h3>
                        <span className="text-sm text-gray-500 flex items-center">
                          <Calendar className="w-4 h-4 mr-1" />
                          {new Date(bill.bill_date).toLocaleDateString('en-IN')}
                        </span>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm text-gray-600 mb-2">
                        <div className="flex items-center">
                          <User className="w-4 h-4 mr-2 text-shodshi-green" />
                          {bill.customer_name}
                        </div>
                        <div className="flex items-center">
                          <Phone className="w-4 h-4 mr-2 text-shodshi-green" />
                          {bill.customer_phone}
                        </div>
                        <div className="flex items-center md:col-span-2">
                          <MapPin className="w-4 h-4 mr-2 text-shodshi-green" />
                          {bill.customer_address}
                        </div>
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="text-sm text-gray-600">
                          Items: {bill.bill_items.length}
                        </div>
                        <div className="text-lg font-bold text-shodshi-green">
                          ₹{bill.total_cost.toLocaleString()}
                        </div>
                      </div>
                    </div>

                    <div className="flex space-x-2 ml-4">
                      <button
                        onClick={() => handleLoadBill(bill)}
                        className="bg-shodshi-green text-white px-3 py-2 rounded-lg hover:bg-shodshi-green-dark transition-colors flex items-center space-x-1 text-sm"
                        title="Load this bill"
                      >
                        <Eye className="w-4 h-4" />
                        <span>Load</span>
                      </button>
                      <button
                        onClick={() => deleteBill(bill.id)}
                        className="bg-red-600 text-white px-3 py-2 rounded-lg hover:bg-red-700 transition-colors flex items-center space-x-1 text-sm"
                        title="Delete this bill"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Preview of items */}
                  <div className="border-t pt-2 mt-2">
                    <div className="text-xs text-gray-500 mb-1">Items:</div>
                    <div className="flex flex-wrap gap-1">
                      {bill.bill_items.slice(0, 3).map((item, index) => (
                        <span
                          key={item.id}
                          className="bg-gray-100 text-gray-700 px-2 py-1 rounded text-xs"
                        >
                          {item.unit}
                        </span>
                      ))}
                      {bill.bill_items.length > 3 && (
                        <span className="text-xs text-gray-500">
                          +{bill.bill_items.length - 3} more
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}